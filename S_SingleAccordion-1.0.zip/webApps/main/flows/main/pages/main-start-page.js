define(['ojs/ojcore'], (oj) => {
  'use strict';


  class PageModule {
    constructor() {
      $(document).ready(() => {
        console.log("Page is now ready");
      });

      let busyStates = oj.Context.getPageContext().getBusyContext().getBusyStates();

      let checkIfPageBusy = () => {
        busyStates = oj.Context.getPageContext().getBusyContext().getBusyStates();
        if (busyStates.length == 0) {          
          $("#busyMsg").fadeOut(400,()=>{
            console.log("Page is now actually ready");
            document.getElementById('busyDlg').close();
            clearInterval(pageInterval);
          });                    
        }
        else{
          console.log("PAGE IS BUSY ",busyStates);
        }
      };

      let pageInterval = setInterval(checkIfPageBusy, 500);
      
    }
  }

  return PageModule;
});
